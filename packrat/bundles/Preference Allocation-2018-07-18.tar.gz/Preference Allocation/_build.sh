#!/usr/bin/env Rscript

rmarkdown::render("slides.Rmd")